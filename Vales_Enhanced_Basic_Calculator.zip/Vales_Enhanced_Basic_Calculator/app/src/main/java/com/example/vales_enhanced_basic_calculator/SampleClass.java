package com.example.vales_enhanced_basic_calculator;

public class SampleClass {

}